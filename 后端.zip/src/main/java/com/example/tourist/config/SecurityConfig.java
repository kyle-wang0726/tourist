package com.example.tourist.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable()) // ✅ 适配 Spring Security 6.1+
                .authorizeHttpRequests(auth -> auth
                        .anyRequest().permitAll() // ✅ 允许所有请求访问
                );

        return http.build();
    }
}
