package com.example.tourist.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

@Configuration
public class HttpClientConfig {

    @Bean
    public RestTemplate restTemplate() throws Exception {
        // 1) 信任所有证书
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    @Override
                    public void checkClientTrusted(X509Certificate[] chain, String authType) { }
                    @Override
                    public void checkServerTrusted(X509Certificate[] chain, String authType) { }
                    @Override
                    public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                }
        };

        // 2) 初始化 SSLContext
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, trustAllCerts, new SecureRandom());

        // 3) 全局设置 HttpsURLConnection 使用这个 SSLContext
        HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
        // 4) 全局关闭主机名校验
        HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);

        // 5) 返回普通的 RestTemplate（走 HttpsURLConnection）
        return new RestTemplate();
    }
}
