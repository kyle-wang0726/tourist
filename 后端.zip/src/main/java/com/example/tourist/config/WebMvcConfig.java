package com.example.tourist.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry reg) {
        // 把 /static/** 映射到本地 upload 目录
        reg.addResourceHandler("/static/**")
                .addResourceLocations("file:upload/");
    }
}
