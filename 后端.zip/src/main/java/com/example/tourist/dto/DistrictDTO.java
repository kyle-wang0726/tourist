package com.example.tourist.dto;

public class DistrictDTO {
    private Integer id;
    private String name;
    private String location;
    private Double avgScore;
    private Double heat;
    private String introduction;
    private String openTime;
    private String imageUrl; // ✅ 确保 DTO 里包含这个字段

    // 构造函数
    public DistrictDTO(Integer id, String name, String location, Double avgScore, Double heat, String introduction, String openTime, String imageUrl) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.avgScore = avgScore;
        this.heat = heat;
        this.introduction = introduction;
        this.openTime = openTime;
        this.imageUrl = imageUrl;
    }

    // Getter & Setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Double getAvgScore() {
        return avgScore;
    }

    public void setAvgScore(Double avgScore) {
        this.avgScore = avgScore;
    }

    public Double getHeat() {
        return heat;
    }

    public void setHeat(Double heat) {
        this.heat = heat;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getOpenTime() {
        return openTime;
    }

    public void setOpenTime(String openTime) {
        this.openTime = openTime;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
