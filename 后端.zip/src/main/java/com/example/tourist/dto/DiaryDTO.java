package com.example.tourist.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DiaryDTO {
    private Integer id;
    private Integer districtId;
    private Long userId;
    private String content;          // 解码后的正文
    private String createdTime;      // 字符串方便前端显示
    private Boolean isPublic;
}
