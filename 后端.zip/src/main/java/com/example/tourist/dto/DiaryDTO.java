package com.example.tourist.dto;

import java.util.Date;
import java.util.List;

/** 前端展示用 DTO，新增 imageUrls */
public class DiaryDTO {

    private Integer id;
    private Integer districtId;
    private Long    userId;
    private String  content;
    private String  createdTime;
    private Boolean isPublic;
    private String videoUrl;
    private int     likes;
    private boolean likedByMe;

    /* 新增 */
    private List<String> imageUrls;

    /* ---------- 无参 + 全参构造 ---------- */
    public DiaryDTO() {}

    public DiaryDTO(Integer id, Integer districtId, Long userId,
                    String content, String createdTime, Boolean isPublic,
                    int likes, boolean likedByMe, List<String> imageUrls) {
        this.id = id; this.districtId = districtId; this.userId = userId;
        this.content = content; this.createdTime = createdTime; this.isPublic = isPublic;
        this.likes = likes; this.likedByMe = likedByMe; this.imageUrls = imageUrls;
    }

    /* ---------- getter / setter ---------- */
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getDistrictId() { return districtId; }
    public void setDistrictId(Integer districtId) { this.districtId = districtId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getCreatedTime() { return createdTime; }
    public void setCreatedTime(String createdTime) { this.createdTime = createdTime; }

    public Boolean getPublic() { return isPublic; }
    public void setPublic(Boolean aPublic) { isPublic = aPublic; }

    public int getLikes() { return likes; }
    public void setLikes(int likes) { this.likes = likes; }

    public boolean isLikedByMe() { return likedByMe; }
    public void setLikedByMe(boolean likedByMe) { this.likedByMe = likedByMe; }

    public List<String> getImageUrls() { return imageUrls; }
    public void setImageUrls(List<String> imageUrls) { this.imageUrls = imageUrls; }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }
}
