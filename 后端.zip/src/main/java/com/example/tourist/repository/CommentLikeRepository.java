package com.example.tourist.repository;

import com.example.tourist.entity.CommentLike;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CommentLikeRepository extends JpaRepository<CommentLike, Integer> {
    Optional<CommentLike> findByUserIdAndCommentId(Long userId, Integer commentId);
    void deleteByUserIdAndCommentId(Long userId, Integer commentId);
}
