package com.example.tourist.repository;

import com.example.tourist.entity.Restaurant;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RestaurantRepository
        extends JpaRepository<Restaurant, Integer> {

    // 根据景点查询 + 自定义排序
    List<Restaurant> findByScenicId(Integer scenicId, Pageable pageable);
    /** 按景点 + 关键词分页搜索 */
    @Query("""
   SELECT r FROM Restaurant r
   WHERE r.scenicId = :sid
     AND ( :kw = ''
            OR r.name     LIKE CONCAT('%', :kw, '%')
            OR r.category LIKE CONCAT('%', :kw, '%') )
""")
    Page<Restaurant> search(@Param("sid") Integer scenicId,
                            @Param("kw")  String  keyword,
                            Pageable pageable);

}
