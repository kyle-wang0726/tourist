package com.example.tourist.repository;

import com.example.tourist.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Integer> {

    // 按时间降序排列
    List<Comment> findByDistrictIdOrderByCreatedTimeDesc(Integer districtId);

    // 按时间升序排列
    List<Comment> findByDistrictIdOrderByCreatedTimeAsc(Integer districtId);

    // 按点赞数降序排列
    List<Comment> findByDistrictIdOrderByLikesDesc(Integer districtId);

    // 按点赞数升序排列
    List<Comment> findByDistrictIdOrderByLikesAsc(Integer districtId);
}
