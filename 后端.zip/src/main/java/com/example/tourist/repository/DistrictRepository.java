package com.example.tourist.repository;

import com.example.tourist.entity.District;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DistrictRepository extends JpaRepository<District, Integer> {

    @Query("SELECT d FROM District d WHERE " +
            "LOWER(d.name) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
            "OR LOWER(d.namePinyin) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    Page<District> searchByNameOrPinyin(@Param("keyword") String keyword, Pageable pageable);
}
