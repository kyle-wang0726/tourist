package com.example.tourist.repository;

import com.example.tourist.entity.District;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DistrictRepository extends JpaRepository<District, Integer> {
    // JPA 已经提供基本的 CRUD 方法，不需要额外写 SQL 查询
}
