package com.example.tourist.repository;

import com.example.tourist.entity.Diary;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DiaryRepository extends JpaRepository<Diary, Integer> {
    List<Diary> findByUserId(Long userId);
    List<Diary> findByDistrictId(Integer districtId);
    List<Diary> findByUserIdAndDistrictId(Long userId, Integer districtId);
}
