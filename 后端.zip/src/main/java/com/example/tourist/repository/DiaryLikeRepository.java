package com.example.tourist.repository;

import com.example.tourist.entity.DiaryLike;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DiaryLikeRepository extends JpaRepository<DiaryLike, Integer> {

    Optional<DiaryLike> findByUserIdAndDiaryId(Long userId, Integer diaryId);

    void deleteByUserIdAndDiaryId(Long userId, Integer diaryId);

    /* 新增：按 diaryId 批量删除 —— 删除日记时会用到 */
    void deleteByDiaryId(Integer diaryId);

    int countByDiaryId(Integer diaryId);
}
