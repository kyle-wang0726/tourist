package com.example.tourist.repository;

import com.example.tourist.entity.DiaryLike;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DiaryLikeRepository extends JpaRepository<DiaryLike, Long> {
    boolean existsByUserIdAndDiaryId(Long userId, Integer diaryId);
    void deleteByUserIdAndDiaryId(Long userId, Integer diaryId);
    long countByDiaryId(Integer diaryId);
}