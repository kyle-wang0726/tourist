package com.example.tourist.repository;

import com.example.tourist.entity.DiaryImage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DiaryImageRepository extends JpaRepository<DiaryImage, Integer> {

    List<DiaryImage> findByDiaryIdOrderBySortOrderAsc(Integer diaryId);

    void deleteByDiaryId(Integer diaryId);
}
