package com.example.tourist.controller;

import com.example.tourist.dto.DiaryDTO;
import com.example.tourist.service.DiaryService;
import com.example.tourist.service.FileStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/diaries")
public class DiaryController {

    private final DiaryService diarySvc;
    private final FileStorageService storage;

    @Autowired
    public DiaryController(DiaryService diarySvc,
                           FileStorageService storage) {
        this.diarySvc = diarySvc;
        this.storage  = storage;
    }

    /* ───────── 新增日记（多图可选） ───────── */
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<DiaryDTO> createDiary(
            /* 直接接收字段，无需 meta 打包 */
            @RequestParam Long    userId,
            @RequestParam Integer districtId,
            @RequestParam String  content,
            @RequestParam boolean isPublic,
            /* 图片可选 */
            @RequestPart(value = "files", required = false) MultipartFile[] files) {

        List<String> imgUrls = storage.save(files);   // 你自己的保存逻辑
        DiaryDTO dto = diarySvc.createDiary(
                new DiaryService.DiaryRequest(userId, districtId, content, isPublic),
                imgUrls);

        return ResponseEntity.ok(dto);
    }

    /* ───────── 删除 ───────── */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDiary(@PathVariable Integer id,
                                            @RequestParam Long userId) {
        diarySvc.deleteDiary(userId, id);
        return ResponseEntity.ok().build();
    }

    /* ───────── 点赞 toggle ───────── */
    @PostMapping("/{id}/like")
    public ResponseEntity<Boolean> like(@PathVariable Integer id,
                                        @RequestBody LikeReq body) {
        return ResponseEntity.ok(diarySvc.toggleLike(body.userId(), id));
    }

    /* ───────── 查询 ───────── */
    @GetMapping("/district/{distId}")
    public ResponseEntity<List<DiaryDTO>> byDistrict(@PathVariable Integer distId,
                                                     @RequestParam(required = false) Long currentUserId) {
        return ResponseEntity.ok(diarySvc.byDistrict(distId, currentUserId));
    }

    @GetMapping("/user/{uid}")
    public ResponseEntity<List<DiaryDTO>> byUser(@PathVariable Long uid,
                                                 @RequestParam(required = false) Long currentUserId) {
        return ResponseEntity.ok(diarySvc.byUser(uid, currentUserId));
    }

    @GetMapping("/user/{uid}/district/{distId}")
    public ResponseEntity<List<DiaryDTO>> byUserAndDist(@PathVariable Long uid,
                                                        @PathVariable Integer distId,
                                                        @RequestParam(required = false) Long currentUserId) {
        return ResponseEntity.ok(diarySvc.byUserAndDist(uid, distId, currentUserId));
    }

    /* ───────── 内部 DTO ───────── */
    public record LikeReq(Long userId) {}
}
