package com.example.tourist.controller;

import com.example.tourist.dto.DiaryDTO;
import com.example.tourist.entity.Diary;
import com.example.tourist.service.DiaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/diaries")
@CrossOrigin(origins = "http://localhost:5173")
public class DiaryController {

    @Autowired
    private DiaryService diaryService;

    @PostMapping
    public ResponseEntity<DiaryDTO> addDiary(@RequestBody DiaryRequest request) {
        DiaryDTO diary = diaryService.addDiary(
                request.getUserId(),
                request.getDistrictId(),
                request.getContent(),
                request.getIsPublic()
        );
        return ResponseEntity.ok(diary);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<DiaryDTO>> getUserDiaries(@PathVariable Long userId) {
        return ResponseEntity.ok(diaryService.getUserDiaries(userId));
    }

    @GetMapping("/district/{districtId}")
    public ResponseEntity<List<DiaryDTO>> districtDiaries(@PathVariable Integer districtId) {
        return ResponseEntity.ok(diaryService.getDistrictDiaries(districtId));
    }

    @GetMapping("/user/{userId}/district/{districtId}")
    public ResponseEntity<List<DiaryDTO>> userDistrictDiaries(
            @PathVariable Long userId,
            @PathVariable Integer districtId
    ) {
        return ResponseEntity.ok(diaryService.getUserDistrictDiaries(userId, districtId));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteDiary(@PathVariable Integer id, @RequestHeader("userId") Long userId) {
        Diary diary = diaryService.getDiaryById(id);
        if (diary == null) {
            return ResponseEntity.status(404).body("日记不存在");
        }
        if (!diary.getUserId().equals(userId)) {
            return ResponseEntity.status(403).body("只能删除自己的日记");
        }
        diaryService.deleteDiary(id);
        return ResponseEntity.ok("删除成功");
    }

    // 内部类用于接收提交请求
    public static class DiaryRequest {
        private Long userId;
        private Integer districtId;
        private String content;
        private Boolean isPublic;

        public Long getUserId() { return userId; }
        public void setUserId(Long userId) { this.userId = userId; }

        public Integer getDistrictId() { return districtId; }
        public void setDistrictId(Integer districtId) { this.districtId = districtId; }

        public String getContent() { return content; }
        public void setContent(String content) { this.content = content; }

        public Boolean getIsPublic() { return isPublic; }
        public void setIsPublic(Boolean isPublic) { this.isPublic = isPublic; }
    }
}
