package com.example.tourist.controller;

import com.example.tourist.dto.DiaryDTO;
import com.example.tourist.service.DiaryService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/diaries")
@CrossOrigin(origins = "http://localhost:5173")
public class DiaryController {

    @Autowired
    private DiaryService diaryService;

    /** 写日记 */
    @PostMapping
    public ResponseEntity<DiaryDTO> addDiary(@RequestBody DiaryRequest request) {
        DiaryDTO diary = diaryService.addDiary(request.getUserId(), request.getDistrictId(), request.getContent());
        return ResponseEntity.ok(diary);
    }

    /** 获取某个用户的所有日记 */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<DiaryDTO>> getUserDiaries(@PathVariable Long userId) {
        return ResponseEntity.ok(diaryService.getUserDiaries(userId));
    }

    /** 获取某个景点的所有日记 */
    @GetMapping("/district/{districtId}")
    public ResponseEntity<List<DiaryDTO>> districtDiaries(@PathVariable Integer districtId) {
        return ResponseEntity.ok(diaryService.getDistrictDiaries(districtId));
    }

    /** 获取某个用户在某个景点的所有日记 */
    @GetMapping("/user/{userId}/district/{districtId}")
    public ResponseEntity<List<DiaryDTO>> userDistrictDiaries(
            @PathVariable Long userId,
            @PathVariable Integer districtId
    ) {
        return ResponseEntity.ok(diaryService.getUserDistrictDiaries(userId, districtId));
    }

    /** 请求体封装类 */
    @Data
    public static class DiaryRequest {
        private Long userId;
        private Integer districtId;
        private String content;
    }
}
