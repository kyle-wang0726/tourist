package com.example.tourist.controller;

import com.example.tourist.dto.DistrictDTO;
import com.example.tourist.entity.District;
import com.example.tourist.repository.DistrictRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/districts")
@CrossOrigin(origins = "http://localhost:5173")  // 允许前端访问
public class TouristDistrictController {

    @Autowired
    private DistrictRepository districtRepository;

    // 获取所有景区
    @GetMapping("")
    public List<DistrictDTO> getAllDistricts() {
        List<District> districts = districtRepository.findAll();
        return districts.stream().map(district -> new DistrictDTO(
                district.getId(),
                district.getName(),
                district.getLocation(),
                district.getAvgScore(),
                district.getHeat(),
                district.getIntroduction(),
                district.getOpenTime(),
                district.getImageUrl()
        )).collect(Collectors.toList());
    }

    // 获取单个景区详情
    @GetMapping("/{id}")
    public ResponseEntity<DistrictDTO> getDistrictById(@PathVariable int id) {
        Optional<District> district = districtRepository.findById(id);
        if (district.isPresent()) {
            District d = district.get();
            DistrictDTO dto = new DistrictDTO(
                    d.getId(),
                    d.getName(),
                    d.getLocation(),
                    d.getAvgScore(),
                    d.getHeat(),
                    d.getIntroduction(),
                    d.getOpenTime(),
                    d.getImageUrl()
            );
            return ResponseEntity.ok(dto);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
}
