package com.example.tourist.controller;

import com.example.tourist.dto.DistrictDTO;
import com.example.tourist.entity.District;
import com.example.tourist.repository.DistrictRepository;
import com.example.tourist.service.FuzzySearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/districts")
@CrossOrigin(origins = "http://localhost:5173") // 允许前端访问
public class TouristDistrictController {

    @Autowired
    private DistrictRepository districtRepository;

    @Autowired
    private FuzzySearchService fuzzySearchService;

    @GetMapping
    public Page<DistrictDTO> getAllDistricts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        Page<District> districts = districtRepository.findAll(PageRequest.of(page, size));
        return districts.map(district -> new DistrictDTO(
                district.getId(),
                district.getName(),
                district.getLocation(),
                district.getAvgScore(),
                district.getHeat(),
                district.getIntroduction(),
                district.getOpenTime(),
                district.getImageUrl()
        ));
    }

    @GetMapping("/search")
    public Page<DistrictDTO> searchDistricts(
            @RequestParam String query,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        Page<District> districtPage = districtRepository.searchByNameOrPinyin(query, PageRequest.of(page, size));
        return districtPage.map(district -> new DistrictDTO(
                district.getId(),
                district.getName(),
                district.getLocation(),
                district.getAvgScore(),
                district.getHeat(),
                district.getIntroduction(),
                district.getOpenTime(),
                district.getImageUrl()
        ));
    }

    @GetMapping("/fuzzy-search")
    public Page<DistrictDTO> fuzzySearch(
            @RequestParam String query,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        List<District> result = fuzzySearchService.searchWithEditDistance(query);

        int start = page * size;
        int end = Math.min(start + size, result.size());
        List<DistrictDTO> content = result.subList(start, end).stream().map(d -> new DistrictDTO(
                d.getId(), d.getName(), d.getLocation(), d.getAvgScore(),
                d.getHeat(), d.getIntroduction(), d.getOpenTime(), d.getImageUrl()
        )).collect(Collectors.toList());

        return new PageImpl<>(content, PageRequest.of(page, size), result.size());
    }

    @GetMapping("/{id}")
    public DistrictDTO getDistrictById(@PathVariable int id) {
        District district = districtRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("景点不存在"));
        return new DistrictDTO(
                district.getId(),
                district.getName(),
                district.getLocation(),
                district.getAvgScore(),
                district.getHeat(),
                district.getIntroduction(),
                district.getOpenTime(),
                district.getImageUrl()
        );
    }

    @GetMapping("/all")
    public List<DistrictDTO> getAllDistrictsWithoutPagination() {
        return districtRepository.findAll().stream()
                .map(district -> new DistrictDTO(
                        district.getId(),
                        district.getName(),
                        district.getLocation(),
                        district.getAvgScore(),
                        district.getHeat(),
                        district.getIntroduction(),
                        district.getOpenTime(),
                        district.getImageUrl()
                ))
                .collect(Collectors.toList());
    }


}