package com.example.tourist.controller;

import com.example.tourist.entity.Comment;
import com.example.tourist.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comments")
@CrossOrigin(origins = "http://localhost:5173")
public class CommentController {

    @Autowired
    private CommentService commentService;

    // 获取评论，并根据排序参数（按时间或点赞数，升序或降序）进行排序
    @GetMapping("/district/{districtId}")
    public ResponseEntity<List<Comment>> getCommentsByDistrict(
            @PathVariable Integer districtId,
            @RequestParam(defaultValue = "time") String sortBy,  // 排序方式，按时间或点赞数
            @RequestParam(defaultValue = "desc") String order // 排序方向，asc 或 desc
    ) {
        List<Comment> comments = commentService.getCommentsByDistrict(districtId, sortBy, order);
        return ResponseEntity.ok(comments);
    }

    // 提交评论
    @PostMapping
    public ResponseEntity<?> postComment(@RequestBody Comment comment) {
        try {
            if (comment.getUserId() == null || comment.getDistrictId() == null) {
                return ResponseEntity.badRequest().body("用户ID或景点ID不能为空");
            }
            Comment savedComment = commentService.addComment(comment);
            return ResponseEntity.ok(savedComment);
        } catch (Exception e) {
            e.printStackTrace();  // 打印错误日志
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("评论提交失败");
        }
    }

    // 点赞评论
    @PostMapping("/{id}/like")
    public ResponseEntity<?> toggleLike(
            @PathVariable Integer id,
            @RequestHeader("userId") Long userId) {
        boolean success = commentService.toggleLike(userId, id);
        return success ? ResponseEntity.ok().build() : ResponseEntity.badRequest().body("操作失败");
    }


    // 删除评论接口
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteComment(@PathVariable Integer id, @RequestHeader("userId") Long userId) {
        // 查找评论
        Comment comment = commentService.getCommentById(id);

        if (comment == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("评论不存在");
        }

        // 验证是否是评论的作者
        if (!comment.getUserId().equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("不能删除其他用户的评论");
        }

        // 删除评论
        commentService.deleteComment(id);
        return ResponseEntity.ok("评论删除成功");
    }
}
