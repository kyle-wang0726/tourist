package com.example.tourist.controller;

import com.example.tourist.entity.Restaurant;
import com.example.tourist.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/restaurants")
public class RestaurantController {

    @Autowired
    private RestaurantService service;

    /**
     * GET /restaurants/scenic/{id}
     * ?q=关键词&sort=rating|distance|price&page=0&size=8
     */
    @GetMapping("/scenic/{id}")
    public Page<Restaurant> byScenicPaged(
            @PathVariable Integer id,
            @RequestParam(defaultValue = "")  String q,
            @RequestParam(defaultValue = "rating") String sort,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        return service.page(id, q, sort, page, size);
    }
}
