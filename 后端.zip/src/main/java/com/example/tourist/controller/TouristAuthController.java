package com.example.tourist.controller;

import com.example.tourist.entity.TouristUser;
import com.example.tourist.service.TouristUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:5173") // 确保允许前端访问
public class TouristAuthController {

    @Autowired
    private TouristUserService userService;

    private final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    /**
     * 用户注册
     */
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody TouristUser user) {
        if (userService.findByUsername(user.getUsername()).isPresent()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("用户名已存在");
        }
        try {
            TouristUser newUser = userService.registerUser(user);
            return ResponseEntity.ok("注册成功");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("注册失败");
        }
    }

    /**
     * 用户登录
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody TouristUser user) {
        Optional<TouristUser> existingUser = userService.findByUsername(user.getUsername());
        if (existingUser.isPresent()) {
            boolean isValid = passwordEncoder.matches(user.getPassword(), existingUser.get().getPassword());
            if (isValid) {
                // 假设这里会生成一个 token，例如通过 JWT 或者其他方式
                String token = "generated_token_example";  // 这里你可以生成 JWT 或其他类型的 token
                return ResponseEntity.ok().body(new LoginResponse(token, existingUser.get().getId()));
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("用户名或密码错误");
            }
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("用户名不存在");
        }
    }

    /**
     * 修改用户信息（用户名 / 邮箱 / 密码）
     */
    @PutMapping("/update-profile")
    public ResponseEntity<?> updateProfile(@RequestBody TouristUser user) {
        Optional<TouristUser> existingUser = userService.findByUsername(user.getUsername());
        if (existingUser.isPresent()) {
            TouristUser updatedUser = existingUser.get();
            if (user.getEmail() != null) updatedUser.setEmail(user.getEmail());
            if (user.getPassword() != null && !user.getPassword().isEmpty()) {
                updatedUser.setPassword(passwordEncoder.encode(user.getPassword())); // 重新加密密码
            }
            userService.saveUser(updatedUser);
            return ResponseEntity.ok("用户信息更新成功");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("用户不存在");
    }

    // 用于返回登录成功时的响应
    public static class LoginResponse {
        private String token;
        private Long userId;

        public LoginResponse(String token, Long userId) {
            this.token = token;
            this.userId = userId;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public Long getUserId() {
            return userId;
        }

        public void setUserId(Long userId) {
            this.userId = userId;
        }
    }
}
