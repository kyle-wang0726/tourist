package com.example.tourist.controller;

import com.example.tourist.service.RunwayService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/video")
public class VideoController {

    private static final Logger logger = LoggerFactory.getLogger(VideoController.class);
    private final RunwayService runwayService;

    public VideoController(RunwayService runwayService) {
        this.runwayService = runwayService;
    }

    @PostMapping("/generate")
    public ResponseEntity<Map<String,String>> generateVideo(@RequestBody VideoGenerateRequest request) {
        logger.info("Received request to generate video: {}", request);
        try {
            // ======= 这里传入 diaryId 作为第一个参数 =======
            String videoUrl = runwayService.generateVideo(
                    request.getDiaryId(),
                    request.getPromptText(),
                    request.getPromptImage(),
                    request.getDuration(),
                    request.getFps(),
                    request.getSeed()
            );
            Map<String,String> result = new HashMap<>();
            result.put("url", videoUrl);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("Video generation failed", e);
            Map<String,String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.status(500).body(error);
        }
    }

    public static class VideoGenerateRequest {
        private Long diaryId;
        private String promptText;
        private String promptImage;
        private int duration;
        private int fps;
        private long seed;

        public Long getDiaryId() { return diaryId; }
        public void setDiaryId(Long diaryId) { this.diaryId = diaryId; }

        public String getPromptText() { return promptText; }
        public void setPromptText(String promptText) { this.promptText = promptText; }

        public String getPromptImage() { return promptImage; }
        public void setPromptImage(String promptImage) { this.promptImage = promptImage; }

        public int getDuration() { return duration; }
        public void setDuration(int duration) { this.duration = duration; }

        public int getFps() { return fps; }
        public void setFps(int fps) { this.fps = fps; }

        public long getSeed() { return seed; }
        public void setSeed(long seed) { this.seed = seed; }

        @Override
        public String toString() {
            return "VideoGenerateRequest{" +
                    "diaryId=" + diaryId +
                    ", promptText='" + promptText + '\'' +
                    ", promptImage='" + promptImage + '\'' +
                    ", duration=" + duration +
                    ", fps=" + fps +
                    ", seed=" + seed +
                    '}';
        }
    }
}
