package com.example.tourist.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "diary_likes", uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "diary_id"}))
@Data
public class DiaryLike {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "diary_id", nullable = false)
    private Integer diaryId;
}