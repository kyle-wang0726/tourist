package com.example.tourist.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "diaries")
public class Diary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "district_id", nullable = false)
    private Integer districtId;

    @Lob
    @Column(name = "content_compressed", nullable = false, columnDefinition = "LONGTEXT")
    private String contentCompressed;

    @Column(name = "created_time")
    private LocalDateTime createdTime = LocalDateTime.now();

    /** 是否公开：true=公开，false=仅自己可见 */
    @Column(name = "is_public", nullable = false)
    private boolean isPublic;

    @Column(name = "video_url")
    private String videoUrl;

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    /* ---------- getter / setter ---------- */
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Integer getDistrictId() { return districtId; }
    public void setDistrictId(Integer districtId) { this.districtId = districtId; }

    public String getContentCompressed() { return contentCompressed; }
    public void setContentCompressed(String contentCompressed) {
        this.contentCompressed = contentCompressed;
    }

    public LocalDateTime getCreatedTime() { return createdTime; }
    public void setCreatedTime(LocalDateTime createdTime) { this.createdTime = createdTime; }

    /* --- 关键的两个方法 --- */
    public boolean isPublic() { return isPublic; }          // 用于 d.isPublic()
    public void setPublic(boolean isPublic) { this.isPublic = isPublic; } // 用于 diary.setPublic(...)
}
