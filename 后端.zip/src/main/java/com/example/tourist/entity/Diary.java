package com.example.tourist.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Table(name = "diaries")
@Data
public class Diary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "district_id", nullable = false)
    private Integer districtId;

    /** 压缩后内容 —— 对应数据库列 content_compressed */
    @Column(name = "content_compressed", columnDefinition = "LONGTEXT", nullable = false)
    private String contentCompressed;

    @Column(name = "created_time", nullable = false)
    private LocalDateTime createdTime;
}
