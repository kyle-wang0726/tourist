package com.example.tourist.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "diary_images")
public class DiaryImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "diary_id", nullable = false)
    private Integer diaryId;

    @Column(nullable = false)
    private String url;

    @Column(name = "sort_order", nullable = false)
    private byte sortOrder = 0;

    /* ---------- getter/setter ---------- */
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getDiaryId() { return diaryId; }
    public void setDiaryId(Integer diaryId) { this.diaryId = diaryId; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public byte getSortOrder() { return sortOrder; }
    public void setSortOrder(byte sortOrder) { this.sortOrder = sortOrder; }
}
