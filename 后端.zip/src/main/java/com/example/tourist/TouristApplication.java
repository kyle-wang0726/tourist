package com.example.tourist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(
		excludeName = "org.springframework.boot.autoconfigure.http.HttpClientAutoConfiguration"
)
public class TouristApplication {
	public static void main(String[] args) {
		SpringApplication.run(TouristApplication.class, args);
	}
}
