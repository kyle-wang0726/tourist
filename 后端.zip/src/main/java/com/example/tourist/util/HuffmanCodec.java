package com.example.tourist.util;

import org.springframework.stereotype.Component;

import java.util.*;

/**
 * 真·哈夫曼压缩：
 * 1. 频次表 → 哈夫曼树 → 编码表
 * 2. 用 BitSet 写位流（只占用 bit，而非字符）
 * 3. BitSet.toByteArray() 得到紧凑字节，再 Base64 编成字符串
 * 4. 头部存 bitLength 与字符频次，解码时可重建哈夫曼树
 *
 * 压缩结果格式：  bitLength#ascii1:freq1;ascii2:freq2;...|BASE64_DATA
 */
@Component
public class HuffmanCodec {

    /* ─────────── 内部节点 ─────────── */
    private static final class Node implements Comparable<Node> {
        char ch;         // 仅叶子节点有效
        int  freq;
        Node left, right;
        Node(char ch, int freq) { this.ch = ch; this.freq = freq; }
        Node(Node l, Node r)    { this.left = l; this.right = r; this.freq = l.freq + r.freq; }
        boolean isLeaf()        { return left == null && right == null; }
        @Override public int compareTo(Node o) { return this.freq - o.freq; }
    }

    /* ─────────── 公开 API ─────────── */

    /** 压缩：返回只含 ASCII 的 Base64 字符串，可安全放入 LONGTEXT */
    public String compress(String text) {
        if (text == null || text.isEmpty()) return "";

        /* 1. 统计频次并建树 */
        Map<Character,Integer> freq = buildFreq(text);
        Node root = buildTree(freq);

        /* 2. 生成编码表 */
        Map<Character,String> code = buildCodeMap(root);

        /* 3. 写位流 */
        BitSet bits = new BitSet();
        int bitIdx = 0;
        for (char c : text.toCharArray()) {
            String seq = code.get(c);
            for (char b : seq.toCharArray()) {
                if (b == '1') bits.set(bitIdx);
                bitIdx++;
            }
        }
        byte[] payload = bits.toByteArray();     // 紧凑字节
        int    bitLen  = bitIdx;                 // 有效位数

        /* 4. 头部：bitLength#ascii:freq;... */
        StringBuilder head = new StringBuilder();
        head.append(bitLen).append('#');
        freq.forEach((ch,f)-> head.append((int)ch).append(':').append(f).append(';'));

        /* 5. Base64 */
        String base64 = Base64.getEncoder().encodeToString(payload);
        return head.append('|').append(base64).toString();
    }

    /** 解压：输入 compress() 的结果，输出原始文本 */
    public String decompress(String data) {
        if (data == null || data.isEmpty() || !data.contains("|")) return "";

        /* 1. 拆头部 / 数据段 */
        String[] seg = data.split("\\|", 2);
        String   head = seg[0];
        String   body = seg[1];

        /* 2. 解析 head：位数 & 频次表 */
        int hashPos = head.indexOf('#');
        int bitLen  = Integer.parseInt(head.substring(0, hashPos));
        String freqPart = head.substring(hashPos + 1);

        Map<Character,Integer> freq = new HashMap<>();
        for (String entry : freqPart.split(";")) {
            if (entry.isEmpty()) continue;
            String[] kv = entry.split(":");
            char ch  = (char) Integer.parseInt(kv[0]);
            int  frq = Integer.parseInt(kv[1]);
            freq.put(ch, frq);
        }

        /* 3. 重建哈夫曼树 */
        Node root = buildTree(freq);

        /* 4. 读取位流 */
        byte[] bytes = Base64.getDecoder().decode(body);
        BitSet bits  = BitSet.valueOf(bytes);

        StringBuilder out = new StringBuilder();
        Node node = root;
        for (int i = 0; i < bitLen; i++) {
            node = bits.get(i) ? node.right : node.left;
            if (node.isLeaf()) {
                out.append(node.ch);
                node = root;
            }
        }
        return out.toString();
    }

    /* ─────────── 私有辅助 ─────────── */

    private Map<Character,Integer> buildFreq(String txt) {
        Map<Character,Integer> m = new HashMap<>();
        for (char c : txt.toCharArray()) m.put(c, m.getOrDefault(c, 0) + 1);
        return m;
    }

    private Node buildTree(Map<Character,Integer> freq) {
        PriorityQueue<Node> pq = new PriorityQueue<>();
        freq.forEach((ch,f)-> pq.add(new Node(ch, f)));
        if (pq.size() == 1) {        // 仅 1 个字符时特殊处理
            pq.add(new Node('\0', 0));
        }
        while (pq.size() > 1) {
            Node a = pq.poll(), b = pq.poll();
            pq.add(new Node(a, b));
        }
        return pq.poll();
    }

    private Map<Character,String> buildCodeMap(Node root) {
        Map<Character,String> map = new HashMap<>();
        buildCodeDfs(root, "", map);
        return map;
    }

    private void buildCodeDfs(Node n, String path, Map<Character,String> map) {
        if (n.isLeaf()) {
            map.put(n.ch, path.isEmpty() ? "0" : path); // 单字符文本给个占位
        } else {
            buildCodeDfs(n.left,  path + "0", map);
            buildCodeDfs(n.right, path + "1", map);
        }
    }
}
