package com.example.tourist.util;

import java.util.*;

public class HuffmanCodec {

    // 节点类
    private static class Node implements Comparable<Node> {
        char ch;
        int freq;
        Node left, right;

        Node(char ch, int freq) {
            this.ch = ch;
            this.freq = freq;
        }

        Node(Node left, Node right) {
            this.left = left;
            this.right = right;
            this.freq = left.freq + right.freq;
        }

        @Override
        public int compareTo(Node other) {
            return this.freq - other.freq;
        }

        public boolean isLeaf() {
            return left == null && right == null;
        }
    }

    // 用于编码传输：结构 + 压缩字符串
    public static String compress(String text) {
        if (text == null || text.isEmpty()) return "";

        Map<Character, Integer> freqMap = buildFrequencyMap(text);
        Node root = buildHuffmanTree(freqMap);
        Map<Character, String> codeMap = buildCodeMap(root);

        StringBuilder encoded = new StringBuilder();
        for (char ch : text.toCharArray()) {
            encoded.append(codeMap.get(ch));
        }

        // 编码表序列化 + 压缩内容
        StringBuilder header = new StringBuilder();
        for (Map.Entry<Character, String> entry : codeMap.entrySet()) {
            header.append((int) entry.getKey()).append(":").append(entry.getValue()).append(";");
        }

        return header.append("|").append(encoded).toString();
    }

    public static String decompress(String data) {
        if (data == null || !data.contains("|")) return "";

        String[] parts = data.split("\\|", 2);
        String header = parts[0];
        String body = parts[1];

        Map<String, Character> decodeMap = new HashMap<>();
        for (String entry : header.split(";")) {
            if (entry.isEmpty()) continue;
            String[] kv = entry.split(":", 2);
            char ch = (char) Integer.parseInt(kv[0]);
            decodeMap.put(kv[1], ch);
        }

        // 解码
        StringBuilder result = new StringBuilder();
        StringBuilder current = new StringBuilder();
        for (char bit : body.toCharArray()) {
            current.append(bit);
            if (decodeMap.containsKey(current.toString())) {
                result.append(decodeMap.get(current.toString()));
                current.setLength(0);
            }
        }

        return result.toString();
    }

    // 辅助方法：构建频率表
    private static Map<Character, Integer> buildFrequencyMap(String text) {
        Map<Character, Integer> freqMap = new HashMap<>();
        for (char ch : text.toCharArray()) {
            freqMap.put(ch, freqMap.getOrDefault(ch, 0) + 1);
        }
        return freqMap;
    }

    // 构建哈夫曼树
    private static Node buildHuffmanTree(Map<Character, Integer> freqMap) {
        PriorityQueue<Node> pq = new PriorityQueue<>();
        for (Map.Entry<Character, Integer> entry : freqMap.entrySet()) {
            pq.offer(new Node(entry.getKey(), entry.getValue()));
        }

        while (pq.size() > 1) {
            Node left = pq.poll();
            Node right = pq.poll();
            pq.offer(new Node(left, right));
        }

        return pq.poll();
    }

    // 从哈夫曼树生成编码表
    private static Map<Character, String> buildCodeMap(Node root) {
        Map<Character, String> map = new HashMap<>();
        buildCodeMapHelper(root, "", map);
        return map;
    }

    private static void buildCodeMapHelper(Node node, String path, Map<Character, String> map) {
        if (node.isLeaf()) {
            map.put(node.ch, path);
        } else {
            buildCodeMapHelper(node.left, path + "0", map);
            buildCodeMapHelper(node.right, path + "1", map);
        }
    }
}
