package com.example.tourist.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class FileStorageService {

    private final Path root = Paths.get("upload");  // 根目录

    /** 保存文件并返回可公开访问的 URL 列表 */
    public List<String> save(MultipartFile[] files) {
        if (files == null || files.length == 0) return List.of();

        String subDir = LocalDate.now()
                .format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        Path dir = root.resolve(subDir);
        try { Files.createDirectories(dir); } catch (IOException ignored) {}

        List<String> urls = new ArrayList<>();
        for (MultipartFile f : files) {
            if (f.isEmpty()) continue;
            String filename = UUID.randomUUID() + "-" + Objects.requireNonNull(f.getOriginalFilename());
            Path target = dir.resolve(filename);
            try (InputStream in = f.getInputStream()) {
                Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
                urls.add("http://localhost:8080/static/" + subDir + "/" + filename);
            } catch (IOException e) {
                throw new RuntimeException("保存文件失败", e);
            }
        }
        return urls;
    }

    /** 删除磁盘文件（按 URL） */
    public void delete(String url) {
        if (url == null) return;
        // url 形如 /static/2025/05/24/xxx.jpg
        String relative = url.replaceFirst("^/static/", "");
        Path file = root.resolve(relative);
        try { Files.deleteIfExists(file); } catch (IOException ignored) {}
    }
}
