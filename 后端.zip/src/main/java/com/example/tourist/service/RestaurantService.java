package com.example.tourist.service;

import com.example.tourist.entity.Restaurant;
import com.example.tourist.repository.RestaurantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Sort.*;
@Service
public class RestaurantService {

    @Autowired
    private RestaurantRepository repo;

    /**
     * 分页+模糊搜索
     * @param scenicId 必填，景点 id
     * @param keyword  可选，名称/类型关键字
     * @param sort     rating | distance | price
     * @param page     页码，从 0 开始
     * @param size     每页条数
     */
    public Page<Restaurant> page(Integer scenicId,
                                 String  keyword,
                                 String  sort,
                                 int page, int size) {

        Sort s = switch (sort) {
            case "distance" -> Sort.by("distance").ascending();

            /* ---- 重点：nullsLast() ---- */
            case "price" ->
                    Sort.by(new Sort.Order(Sort.Direction.ASC, "price")
                            .nullsLast());          // ⬅⬅⬅ 让 NULL 排到最后

            default         -> Sort.by("rating").descending();
        };

        Pageable p = PageRequest.of(page, size, s);
        String kw = (keyword == null) ? "" : keyword.trim();

        return repo.search(scenicId, kw, p);
    }
}
