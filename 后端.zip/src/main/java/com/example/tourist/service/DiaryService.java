package com.example.tourist.service;

import com.example.tourist.dto.DiaryDTO;
import com.example.tourist.entity.Diary;
import com.example.tourist.repository.DiaryRepository;
import com.example.tourist.util.HuffmanCodec;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DiaryService {

    @Autowired
    private DiaryRepository diaryRepository;

    /** 写日记（压缩内容） */
    public DiaryDTO addDiary(Long userId, Integer districtId, String rawContent) {
        Diary diary = new Diary();
        diary.setUserId(userId);
        diary.setDistrictId(districtId);
        diary.setContentCompressed(HuffmanCodec.compress(rawContent));
        diary.setCreatedTime(LocalDateTime.now());

        Diary saved = diaryRepository.save(diary);
        return new DiaryDTO(
                saved.getId(),
                saved.getDistrictId(),
                saved.getUserId(),
                rawContent,  // 注意：这里我们返回原始未压缩内容
                saved.getCreatedTime().toString()
        );
    }


    /** 获取用户全部日记（解码后返回 DTO） */
    public List<DiaryDTO> getUserDiaries(Long userId) {
        return diaryRepository.findByUserId(userId).stream()
                .map(d -> new DiaryDTO(
                        d.getId(),
                        d.getDistrictId(),
                        d.getUserId(),
                        HuffmanCodec.decompress(d.getContentCompressed()),
                        d.getCreatedTime().toString()
                ))
                .collect(Collectors.toList());
    }

    /** 获取指定景点的所有日记（解码后返回 DTO） */
    public List<DiaryDTO> getDistrictDiaries(Integer districtId) {
        return diaryRepository.findByDistrictId(districtId).stream()
                .map(d -> new DiaryDTO(
                        d.getId(),
                        d.getDistrictId(),
                        d.getUserId(),
                        HuffmanCodec.decompress(d.getContentCompressed()),
                        d.getCreatedTime().toString()
                ))
                .collect(Collectors.toList());
    }

    /** 获取指定用户在某个景点的所有日记（解码后返回 DTO） */
    public List<DiaryDTO> getUserDistrictDiaries(Long userId, Integer districtId) {
        return diaryRepository.findByUserIdAndDistrictId(userId, districtId).stream()
                .map(d -> new DiaryDTO(
                        d.getId(),
                        d.getDistrictId(),
                        d.getUserId(),
                        HuffmanCodec.decompress(d.getContentCompressed()),
                        d.getCreatedTime().toString()
                ))
                .collect(Collectors.toList());
    }
}
