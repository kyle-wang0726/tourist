package com.example.tourist.service;

import com.example.tourist.dto.DiaryDTO;
import com.example.tourist.entity.Diary;
import com.example.tourist.entity.DiaryImage;
import com.example.tourist.entity.DiaryLike;
import com.example.tourist.repository.DiaryImageRepository;
import com.example.tourist.repository.DiaryLikeRepository;
import com.example.tourist.repository.DiaryRepository;
import com.example.tourist.util.HuffmanCodec;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DiaryService {

    private final DiaryRepository diaryRepo;
    private final DiaryLikeRepository likeRepo;
    private final DiaryImageRepository imgRepo;
    private final HuffmanCodec codec;
    private final FileStorageService storage;

    public DiaryService(DiaryRepository diaryRepo,
                        DiaryLikeRepository likeRepo,
                        DiaryImageRepository imgRepo,
                        HuffmanCodec codec,
                        FileStorageService storage) {
        this.diaryRepo = diaryRepo;
        this.likeRepo  = likeRepo;
        this.imgRepo   = imgRepo;
        this.codec     = codec;
        this.storage   = storage;
    }

    /* ---------- 新增日记 ---------- */
    @Transactional
    public DiaryDTO createDiary(DiaryRequest req, List<String> imgUrls) {
        Diary diary = new Diary();
        diary.setUserId(req.userId());
        diary.setDistrictId(req.districtId());
        diary.setContentCompressed(codec.compress(req.content()));
        diary.setPublic(req.isPublic());
        diary = diaryRepo.save(diary);

        byte order = 0;
        for (String url : imgUrls) {
            DiaryImage img = new DiaryImage();
            img.setDiaryId(diary.getId());
            img.setUrl(url);
            img.setSortOrder(order++);
            imgRepo.save(img);
        }
        return toDTO(diary, req.userId());
    }

    /* ---------- 删除日记 ---------- */
    @Transactional
    public void deleteDiary(Long userId, Integer diaryId) {
        diaryRepo.findById(diaryId).ifPresent(d -> {
            if (!d.getUserId().equals(userId))
                throw new IllegalArgumentException("只能删除自己的日记");
            imgRepo.findByDiaryIdOrderBySortOrderAsc(diaryId)
                    .forEach(img -> storage.delete(img.getUrl()));
            diaryRepo.delete(d);
            likeRepo.deleteByDiaryId(diaryId);
        });
    }

    /* ---------- 点赞 toggle ---------- */
    @Transactional
    public boolean toggleLike(Long userId, Integer diaryId) {
        Optional<DiaryLike> ex = likeRepo.findByUserIdAndDiaryId(userId, diaryId);
        if (ex.isPresent()) {
            likeRepo.delete(ex.get());
            return false;
        } else {
            DiaryLike l = new DiaryLike();
            l.setUserId(userId);
            l.setDiaryId(diaryId);
            likeRepo.save(l);
            return true;
        }
    }

    /* ---------- 查询 ---------- */
    public List<DiaryDTO> byDistrict(Integer distId, Long curUid) {
        return diaryRepo.findByDistrictId(distId).stream()
                .filter(d -> d.isPublic() || d.getUserId().equals(curUid))
                .map(d -> toDTO(d, curUid))
                .collect(Collectors.toList());
    }

    public List<DiaryDTO> byUser(Long uid, Long curUid) {
        return diaryRepo.findByUserId(uid).stream()
                .filter(d -> d.isPublic() || d.getUserId().equals(curUid))
                .map(d -> toDTO(d, curUid))
                .collect(Collectors.toList());
    }

    public List<DiaryDTO> byUserAndDist(Long uid, Integer distId, Long curUid) {
        return diaryRepo.findByUserIdAndDistrictId(uid, distId).stream()
                .filter(d -> d.isPublic() || d.getUserId().equals(curUid))
                .map(d -> toDTO(d, curUid))
                .collect(Collectors.toList());
    }

    /* ---------- DTO 转换 ---------- */
    private DiaryDTO toDTO(Diary diary, Long curUid) {
        List<String> urls = imgRepo.findByDiaryIdOrderBySortOrderAsc(diary.getId())
                .stream().map(DiaryImage::getUrl).toList();

        DiaryDTO dto = new DiaryDTO();
        dto.setId(diary.getId());
        dto.setUserId(diary.getUserId());
        dto.setDistrictId(diary.getDistrictId());
        dto.setCreatedTime(diary.getCreatedTime().toString());
        dto.setPublic(diary.isPublic());
        dto.setContent(codec.decompress(diary.getContentCompressed()));
        dto.setLikes(likeRepo.countByDiaryId(diary.getId()));
        dto.setLikedByMe(likeRepo.findByUserIdAndDiaryId(curUid, diary.getId()).isPresent());
        dto.setImageUrls(urls);
        dto.setVideoUrl(diary.getVideoUrl());  // ★ 确保 DTO 里也有个 videoUrl 字段
        return dto;
    }

    /* ---------- 新增：保存视频引用 ---------- */
    @Transactional
    public void attachVideo(Integer diaryId, String videoUrl) {
        Diary d = diaryRepo.findById(diaryId)
                .orElseThrow(() -> new IllegalArgumentException("日记不存在: " + diaryId));
        d.setVideoUrl(videoUrl);
        diaryRepo.save(d);
    }

    public record DiaryRequest(Long userId, Integer districtId, String content, boolean isPublic) {}
}
