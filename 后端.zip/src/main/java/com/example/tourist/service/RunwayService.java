package com.example.tourist.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

@Service
public class RunwayService {

    private static final Logger logger = LoggerFactory.getLogger(RunwayService.class);
    private final RestTemplate restTemplate;

    /* ============ 你的 Runway 账户信息 ============ */
    private static final String BASE_URL    = "https://api.dev.runwayml.com";
    private static final String API_KEY     = "key_fc87cd9a0ca5e0927d929ece36deae5233c51f871dbc5a91f33370732eaed726489ea95988890f454e816fdf9d98a4f6742f7db720c4614d05a9a3ead336c8c4";
    private static final String API_VERSION = "2024-11-06";

    /* ============ 本地文件映射根目录 ============
       这里写你 FileStorageService 实际把文件保存到磁盘的目录，
       例如 “/srv/tourist/uploads”。若你的 URL 里已经带完整磁盘
       路径，可把它留空。 */
    private static final Path LOCAL_FS_ROOT = Paths.get("/srv/tourist/uploads");

    public RunwayService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /**
     * 生成视频（透明处理 promptImage）
     *
     * @param promptImage - 可以是：
     *                    1. 站外 https URL
     *                    2. 站内 http://localhost:8080/… 之类 URL
     *                    3. 相对路径 /files/xxx.jpg
     *                    4. 已经是 data:uri
     */
    public String generateVideo(
            Long  diaryId,
            String promptText,
            String promptImage,
            int    duration,   // 5 or 10
            int    fps,
            long   seed) {

        logger.info("generateVideo diaryId={} image={}", diaryId, promptImage);

        /* ===== 1. 处理图片：转为 data URI ===== */
        String imageUri = null;
        if (promptImage != null && !promptImage.isBlank()) {
            imageUri = ensureDataUri(promptImage.trim());
            logger.debug("Converted promptImage -> uri (length={} chars)", imageUri.length());
        }

        /* ===== 2. 组装请求体 ===== */
        Map<String,Object> body = new LinkedHashMap<>();
        if (imageUri != null) {
            Map<String,Object> img = Map.of(
                    "uri",      imageUri,
                    "position", "first");
            body.put("promptImage", List.of(img));
        }
        body.put("promptText", promptText);
        body.put("model",      "gen4_turbo");
        body.put("ratio",      "1280:720");
        body.put("duration",   duration);
        body.put("fps",        fps);
        body.put("seed",       seed);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("X-Runway-Version", API_VERSION);
        headers.setBearerAuth(API_KEY);

        /* ===== 3. 提交 runway 任务 ===== */
        TaskResponse submit;
        try {
            submit = restTemplate.exchange(
                    BASE_URL + "/v1/image_to_video",
                    HttpMethod.POST,
                    new HttpEntity<>(body, headers),
                    TaskResponse.class).getBody();
        } catch (HttpStatusCodeException e) {
            throw new RuntimeException("Runway 提交失败: "+e.getStatusCode()+" "+e.getResponseBodyAsString(), e);
        }

        if (submit == null || submit.getId() == null)
            throw new RuntimeException("Runway 未返回任务 ID");

        /* ===== 4. 轮询直到完成 ===== */
        String taskId = submit.getId();
        String pollUrl = BASE_URL + "/v1/tasks/" + taskId;
        TaskResponse status;

        do {
            try { Thread.sleep(3_000); } catch (InterruptedException ie) {
                Thread.currentThread().interrupt(); throw new RuntimeException(ie);
            }
            status = restTemplate.exchange(
                    pollUrl, HttpMethod.GET,
                    new HttpEntity<>(headers), TaskResponse.class).getBody();
            logger.debug("poll {} -> {}", taskId, status != null ? status.getStatus() : null);
        } while (status == null || !( "SUCCEEDED".equals(status.getStatus()) || "FAILED".equals(status.getStatus())));

        if (!"SUCCEEDED".equals(status.getStatus()))
            throw new RuntimeException("Runway 任务失败: "+status.getStatus());

        List<String> out = status.getOutput();
        if (out == null || out.isEmpty())
            throw new RuntimeException("Runway 返回为空 output");

        return out.get(0);    // 成功 URL
    }

    /* ------------------------------------------------------------------ */
    /*                          私有辅助方法                               */
    /* ------------------------------------------------------------------ */

    /** 把 URL/相对路径 转成 data:image/...;base64,xxxx */
    private String ensureDataUri(String src) {

        // 1. 已经是 data URI
        if (src.startsWith("data:")) return src;

        byte[] bytes;
        String ext;   // 用于 mime

        try {
            if (src.startsWith("http")) {
                /* 2. HTTP(S) – 直接下载到内存 */
                ResponseEntity<byte[]> resp = restTemplate.getForEntity(src, byte[].class);
                if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null)
                    throw new IOException("下载失败 HTTP "+resp.getStatusCode());

                bytes = resp.getBody();
                ext   = guessExtFromUrl(src);

            } else {
                /* 3. 相对路径 – 在本地磁盘读取 */
                Path p = LOCAL_FS_ROOT.resolve(src.startsWith("/")
                                ? src.substring(1) : src)
                        .normalize();
                bytes = Files.readAllBytes(p);
                ext   = guessExtFromUrl(p.toString());
            }

        } catch (Exception e) {
            logger.error("读取图片失败: {}", src, e);
            throw new RuntimeException("无法读取图片: "+src, e);
        }

        String b64 = Base64.getEncoder().encodeToString(bytes);
        return "data:image/" + ext + ";base64," + b64;
    }

    /** 粗略按文件名猜扩展名，默认为 png */
    private String guessExtFromUrl(String url) {
        int dot = url.lastIndexOf('.');
        if (dot > 0 && dot < url.length() - 1) {
            String ext = url.substring(dot + 1).toLowerCase(Locale.ROOT);
            // 只保留常见几种，其他一律 png
            return switch (ext) {
                case "jpg", "jpeg" -> "jpeg";
                case "webp"        -> "webp";
                case "gif"         -> "gif";
                default             -> "png";
            };
        }
        return "png";
    }

    /* ------------------------------------------------------------------ */
    /*                       Runway 任务回包映射                           */
    /* ------------------------------------------------------------------ */
    @JsonIgnoreProperties(ignoreUnknown = true)
    private static class TaskResponse {
        private String id;
        private String status;
        private List<String> output;

        @JsonProperty("id")     public String getId() { return id; }
        @JsonProperty("id")     public void   setId(String id) { this.id = id; }

        @JsonProperty("status") public String getStatus() { return status; }
        @JsonProperty("status") public void   setStatus(String status) { this.status = status; }

        @JsonProperty("output") public List<String> getOutput() { return output; }
        @JsonProperty("output") public void   setOutput(List<String> output) { this.output = output; }
    }
}
