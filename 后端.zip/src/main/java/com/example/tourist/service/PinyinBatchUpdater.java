package com.example.tourist.service;

import com.example.tourist.entity.District;
import com.example.tourist.repository.DistrictRepository;
import net.sourceforge.pinyin4j.PinyinHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// import jakarta.annotation.PostConstruct;
import java.util.List;

@Service
public class PinyinBatchUpdater {

    @Autowired
    private DistrictRepository districtRepository;

    // ✅ 此方法已禁用自动执行，如需更新请手动调用
    // @PostConstruct
    public void updatePinyinFields() {
        List<District> districts = districtRepository.findAll();

        for (District district : districts) {
            if (district.getNamePinyin() == null || district.getNamePinyin().isEmpty()) {
                String name = district.getName();
                StringBuilder pinyin = new StringBuilder();

                for (char c : name.toCharArray()) {
                    String[] pinyins = PinyinHelper.toHanyuPinyinStringArray(c);
                    if (pinyins != null && pinyins.length > 0) {
                        pinyin.append(pinyins[0].replaceAll("[^a-zA-Z]", "")); // 去掉声调
                    } else {
                        pinyin.append(c); // 非中文字符直接加
                    }
                }

                district.setNamePinyin(pinyin.toString().toLowerCase());
                districtRepository.save(district);
            }
        }

        System.out.println("✅ 拼音字段更新完成！");
    }
}
