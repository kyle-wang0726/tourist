package com.example.tourist.service;

import com.example.tourist.entity.District;
import com.example.tourist.repository.DistrictRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@Service
public class FuzzySearchService {

    @Autowired
    private DistrictRepository districtRepository;

    public List<District> searchWithEditDistance(String query) {
        List<District> all = districtRepository.findAll();
        String q = query.toLowerCase(Locale.ROOT);

        // 先找包含关键词的
        List<District> exactMatches = all.stream()
                .filter(d -> containsIgnoreCase(d.getName(), q) || containsIgnoreCase(d.getNamePinyin(), q))
                .collect(Collectors.toList());

        // 再用编辑距离补充一些近似的
        List<District> fuzzyMatches = all.stream()
                .filter(d -> !exactMatches.contains(d)) // 避免重复
                .sorted(Comparator.comparingInt(d ->
                        getMinDistance(q, d.getName(), d.getNamePinyin())
                ))
                .filter(d -> getMinDistance(q, d.getName(), d.getNamePinyin()) <= 6)
                .collect(Collectors.toList());

        List<District> result = new ArrayList<>();
        result.addAll(exactMatches);
        result.addAll(fuzzyMatches);
        return result;
    }

    private boolean containsIgnoreCase(String source, String target) {
        return source != null && source.toLowerCase(Locale.ROOT).contains(target);
    }

    private int getMinDistance(String query, String... targets) {
        int min = Integer.MAX_VALUE;
        for (String target : targets) {
            if (target != null) {
                min = Math.min(min, levenshtein(query.toLowerCase(), target.toLowerCase()));
            }
        }
        return min;
    }

    private int levenshtein(String a, String b) {
        int[][] dp = new int[a.length() + 1][b.length() + 1];

        for (int i = 0; i <= a.length(); i++) dp[i][0] = i;
        for (int j = 0; j <= b.length(); j++) dp[0][j] = j;

        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {
                int cost = (a.charAt(i - 1) == b.charAt(j - 1)) ? 0 : 1;
                dp[i][j] = Math.min(Math.min(
                                dp[i - 1][j] + 1,
                                dp[i][j - 1] + 1),
                        dp[i - 1][j - 1] + cost
                );
            }
        }
        return dp[a.length()][b.length()];
    }
}
