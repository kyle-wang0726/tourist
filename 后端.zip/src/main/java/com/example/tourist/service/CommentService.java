package com.example.tourist.service;

import com.example.tourist.entity.Comment;
import com.example.tourist.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    // 获取评论，根据排序方式决定
    public List<Comment> getCommentsByDistrict(Integer districtId, String sortBy, String order) {
        if ("likes".equals(sortBy)) {
            if ("asc".equals(order)) {
                // 按点赞数升序
                return commentRepository.findByDistrictIdOrderByLikesAsc(districtId);
            } else {
                // 按点赞数降序
                return commentRepository.findByDistrictIdOrderByLikesDesc(districtId);
            }
        } else {
            if ("asc".equals(order)) {
                // 按时间升序
                return commentRepository.findByDistrictIdOrderByCreatedTimeAsc(districtId);
            } else {
                // 按时间降序
                return commentRepository.findByDistrictIdOrderByCreatedTimeDesc(districtId);
            }
        }
    }

    public Comment addComment(Comment comment) {
        return commentRepository.save(comment);
    }

    public boolean likeComment(Integer commentId) {
        Comment comment = commentRepository.findById(commentId).orElse(null);
        if (comment != null) {
            comment.setLikes(comment.getLikes() + 1);
            commentRepository.save(comment);
            return true;
        }
        return false;
    }

    public Comment getCommentById(Integer id) {
        return commentRepository.findById(id).orElse(null);
    }

    public void deleteComment(Integer id) {
        commentRepository.deleteById(id);
    }
}
