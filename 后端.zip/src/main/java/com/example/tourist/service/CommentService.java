package com.example.tourist.service;

import com.example.tourist.entity.Comment;
import com.example.tourist.entity.CommentLike;
import com.example.tourist.repository.CommentLikeRepository;
import com.example.tourist.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private CommentLikeRepository commentLikeRepository;

    // 获取评论，根据排序方式决定
    public List<Comment> getCommentsByDistrict(Integer districtId, String sortBy, String order) {
        if ("likes".equals(sortBy)) {
            if ("asc".equals(order)) {
                return commentRepository.findByDistrictIdOrderByLikesAsc(districtId);
            } else {
                return commentRepository.findByDistrictIdOrderByLikesDesc(districtId);
            }
        } else {
            if ("asc".equals(order)) {
                return commentRepository.findByDistrictIdOrderByCreatedTimeAsc(districtId);
            } else {
                return commentRepository.findByDistrictIdOrderByCreatedTimeDesc(districtId);
            }
        }
    }

    // 添加评论
    public Comment addComment(Comment comment) {
        return commentRepository.save(comment);
    }

    // 点赞 / 取消点赞
    @Transactional
    public boolean toggleLike(Long userId, Integer commentId) {
        try {
            Optional<Comment> commentOpt = commentRepository.findById(commentId);
            if (commentOpt.isEmpty()) {
                System.out.println("评论不存在");
                return false;
            }

            Comment comment = commentOpt.get();
            Optional<CommentLike> existingLike = commentLikeRepository.findByUserIdAndCommentId(userId, commentId);

            if (existingLike.isPresent()) {
                System.out.println("取消点赞中...");
                comment.setLikes(Math.max(0, comment.getLikes() - 1));
                commentRepository.save(comment);
                commentLikeRepository.deleteByUserIdAndCommentId(userId, commentId);
            } else {
                System.out.println("添加点赞中...");
                comment.setLikes(comment.getLikes() + 1);
                commentRepository.save(comment);

                CommentLike like = new CommentLike();
                like.setUserId(userId);
                like.setCommentId(commentId);
                commentLikeRepository.save(like);
            }

            return true;
        } catch (Exception e) {
            e.printStackTrace(); // 打印到控制台
            return false;
        }
    }


    // 获取单个评论
    public Comment getCommentById(Integer id) {
        return commentRepository.findById(id).orElse(null);
    }

    // 删除评论
    public void deleteComment(Integer id) {
        commentRepository.deleteById(id);
    }
}
