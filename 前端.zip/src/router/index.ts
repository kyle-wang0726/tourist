import { createRouter, createWebHistory } from "vue-router";
import Home from "@/view/Home.vue";
import Login from "@/components/Login.vue";
import Register from "@/components/Register.vue";
import Search from "@/view/Search.vue";  // 旅游搜索页面
import Profile from "@/view/Profile.vue";  // 个人信息页面
import Details from "@/view/Details.vue";  //  确保与文件名一致

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      redirect: "/login",
    },
    {
      path: "/login",
      component: Login,
    },
    {
      path: "/register",
      component: Register,
    },
    {
      path: "/home",
      component: Home,
    },
    {
      path: "/search",
      component: Search,  // 旅游推荐
    },
    {
      path: "/profile",
      component: Profile,  // 个人信息管理
    },
    {
      path: "/detail/:id",  // ✅ 确保可以访问景点详情页
      component: Details,
      props: true,  // ✅ 允许通过 props 传递 id
    },
  ],
});

export default router;
