import { createRouter, createWebHistory } from "vue-router";
import Home from "@/view/Home.vue";
import Login from "@/components/Login.vue";
import Register from "@/components/Register.vue";
import Search from "@/view/Search.vue";      // 旅游搜索页面
import Profile from "@/view/Profile.vue";    // 个人信息页面
import Details from "@/view/Details.vue";    // 景点详情页
import DiaryPage from "@/view/DiaryPage.vue"; // ✅ 新增：旅游日记页面

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      redirect: "/login",
    },
    {
      path: "/login",
      component: Login,
    },
    {
      path: "/register",
      component: Register,
    },
    {
      path: "/home",
      component: Home,
    },
    {
      path: "/search",
      component: Search,
    },
    {
      path: "/profile",
      component: Profile,
    },
    {
      path: "/detail/:id",
      component: Details,
      props: true,
    },
    {
      path: "/diary", // ✅ 新增旅游日记页面
      component: DiaryPage,
    },
  ],
});

export default router;
