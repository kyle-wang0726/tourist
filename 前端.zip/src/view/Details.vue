<template>
    <div class="detail-container">
        <div v-if="district" class="district-info">
            <h2>{{ district.name }}</h2>
            <img :src="district.imageUrl" class="detail-image" />
            <p><strong>位置：</strong>{{ district.location }}</p>
            <p><strong>评分：</strong>{{ district.avgScore }}</p>
            <p><strong>热度：</strong>{{ district.heat }}</p>
            <p><strong>介绍：</strong>{{ district.introduction }}</p>
            <p><strong>开放时间：</strong>{{ district.openTime }}</p>
        </div>

        <div v-else>正在加载数据...</div>

        <!-- 返回按钮 -->
        <div class="back-button-container">
            <button @click="goBackToSearch">返回搜索</button>
        </div>

        <!-- 评论排序选择 -->
        <div class="comment-sort">
            <label for="sortOption">排序方式：</label>
            <select v-model="sortOption" @change="fetchComments">
                <option value="time">按时间排序</option>
                <option value="likes">按点赞数排序</option>
            </select>
            <label for="orderOption">排序顺序：</label>
            <select v-model="orderOption" @change="fetchComments">
                <option value="desc">降序</option>
                <option value="asc">升序</option>
            </select>
        </div>

        <!-- 评论区 -->
        <div class="comment-section">
            <h3>用户评论</h3>
            <div v-if="comments.length === 0" class="no-comment">暂无评论</div>

            <div v-for="c in comments" :key="c.id" class="comment-item">
                <p class="comment-content">{{ c.content }}</p>
                <div class="comment-footer">
                    <span class="comment-time">{{ formatTime(c.createdTime) }}</span>
                    <button @click="likeComment(c.id)">👍 {{ c.likes }}</button>
                    <!-- 删除按钮，仅显示给评论作者 -->
                    <button v-if="c.userId === userId" @click="deleteComment(c.id)">删除</button>
                </div>
            </div>

            <div v-if="isLoggedIn" class="comment-input">
                <textarea v-model="newComment" placeholder="写下你的评论..." />
                <button @click="submitComment">发表评论</button>
            </div>
            <div v-else class="login-warning">请登录后发表评论。</div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router'; // 引入 useRouter
import api from '../api/api';

const route = useRoute();
const router = useRouter(); // 创建 router 实例
const districtId = Number(route.params.id);
const district = ref<any>(null);
const comments = ref<any[]>([]);
const newComment = ref('');
const isLoggedIn = !!localStorage.getItem('token');
const userId = Number(localStorage.getItem('userId'));
const sortOption = ref('time');  // 默认按时间排序
const orderOption = ref('desc');  // 默认降序

// 获取景点信息
const fetchDistrict = async () => {
    try {
        const res = await api.get(`/districts/${districtId}`);
        district.value = res.data;
    } catch (e) {
        console.error('加载景点失败', e);
    }
};

// 获取评论并根据排序参数更新
const fetchComments = async () => {
    console.log("Fetching comments with sortBy:", sortOption.value, "order:", orderOption.value);  // 调试日志
    try {
        const res = await api.get(`/comments/district/${districtId}`, {
            params: {
                sortBy: sortOption.value,  // 排序方式（按时间或点赞数）
                order: orderOption.value  // 排序顺序（升序或降序）
            }
        });
        comments.value = res.data;
    } catch (e) {
        console.error('加载评论失败', e);
    }
};

// 提交评论
const submitComment = async () => {
    if (!newComment.value.trim()) return;
    if (!userId) {
        alert("请先登录！");
        return;
    }
    try {
        await api.post('/comments', {
            userId,
            districtId,
            content: newComment.value
        });
        newComment.value = '';
        fetchComments();  // 提交成功后刷新评论
    } catch (e) {
        console.error('评论提交失败', e);
    }
};

// 点赞评论
const likeComment = async (id: number) => {
    try {
        await api.post(`/comments/${id}/like`);
        fetchComments();  // 点赞后刷新评论
    } catch (e) {
        console.error('点赞失败', e);
    }
};

// 删除评论
const deleteComment = async (id: number) => {
    try {
        await api.delete(`/comments/${id}`, {
            headers: {
                userId: userId.toString(),  // 传递当前用户的 userId
            }
        });
        fetchComments();  // 删除评论后刷新列表
    } catch (e) {
        console.error('删除评论失败', e);
    }
};

// 格式化时间
const formatTime = (iso: string) => {
    return new Date(iso).toLocaleString();
};

// 返回到搜索页面
const goBackToSearch = () => {
    router.push('/search');  // 跳转到搜索页面
};

// 页面加载时获取景点信息和评论
onMounted(() => {
    fetchDistrict();
    fetchComments();
});
</script>

<style scoped>
.detail-container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}

.detail-image {
    width: 100%;
    height: auto;
    margin-bottom: 10px;
}

.comment-sort {
    margin-bottom: 20px;
}

.comment-sort select {
    padding: 5px;
}

.comment-section {
    margin-top: 40px;
}

.comment-input textarea {
    width: 100%;
    height: 80px;
    margin-top: 10px;
    padding: 10px;
}

.comment-input button {
    margin-top: 8px;
    background-color: #42b983;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

.comment-item {
    background: #f5f5f5;
    padding: 10px;
    margin-top: 10px;
    border-radius: 5px;
}

.comment-footer {
    display: flex;
    justify-content: space-between;
    margin-top: 5px;
    font-size: 14px;
    color: #666;
}

.login-warning {
    color: red;
    margin-top: 10px;
}

/* 返回按钮样式，定位到右上角 */
.back-button-container {
    position: absolute;
    top: 20px;
    right: 20px;
}

.back-button-container button {
    padding: 10px 20px;
    background-color: #42b983;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
</style>
