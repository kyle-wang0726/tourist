<template>
    <div class="search-container">
        <h2>旅游景点推荐</h2>

        <!-- 返回按钮 -->
        <div class="back-button-container">
            <button @click="goBackToHome">返回首页</button>
        </div>

        <!-- 搜索框 -->
        <div class="search-bar">
            <input v-model="searchQuery" @keyup.enter="handleSearch" placeholder="请输入景点名称或拼音（如：国博 / guobo）"
                class="search-input" />
            <button @click="handleSearch" class="search-button">搜索</button>
        </div>

        <!-- 景点列表 -->
        <div class="district-list">
            <div v-for="district in districts" :key="district.id" class="district-item">
                <img :src="district.imageUrl" alt="景点图片" class="district-image" @click="goToDetail(district.id)"
                    @error="handleImageError" />
                <h3>{{ district.name }}</h3>
            </div>
        </div>

        <!-- 分页控制 -->
        <div class="pagination">
            <button @click="prevPage" :disabled="currentPage === 1">上一页</button>
            <span>第 {{ currentPage }} 页 / 共 {{ totalPages }} 页</span>
            <button @click="nextPage" :disabled="currentPage >= totalPages">下一页</button>
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";
import { getDistricts, fuzzySearchDistricts } from "../api/api";

interface District {
    id: number;
    name: string;
    imageUrl: string;
}

const router = useRouter();
const searchQuery = ref("");
const districts = ref<District[]>([]);
const currentPage = ref(1);
const pageSize = 10;
const totalPages = ref(1);

const handleSearch = () => {
    currentPage.value = 1;
    fetchData();
};

const fetchData = async () => {
    try {
        if (searchQuery.value.trim() === "") {
            const res = await getDistricts(currentPage.value - 1, pageSize);
            districts.value = res.data.content;
            totalPages.value = res.data.totalPages;
        } else {
            const res = await fuzzySearchDistricts(searchQuery.value.trim(), currentPage.value - 1, pageSize);
            districts.value = res.data.content;
            totalPages.value = res.data.totalPages;
        }
    } catch (err) {
        console.error("获取数据失败", err);
    }
};

const goToDetail = (id: number) => {
    router.push(`/detail/${id}`);
};

const prevPage = () => {
    if (currentPage.value > 1) {
        currentPage.value--;
        fetchData();
    }
};

const nextPage = () => {
    if (currentPage.value < totalPages.value) {
        currentPage.value++;
        fetchData();
    }
};

const handleImageError = (event: Event) => {
    (event.target as HTMLImageElement).src = "https://via.placeholder.com/300x200";
};

// 例如在 Search.vue 和 Details.vue 中的 goBackToHome 方法
const goBackToHome = () => {
    router.push('/home');  // 确保跳转到 /home 页面
};


onMounted(fetchData);
</script>

<style scoped>
.search-container {
    text-align: center;
    padding: 20px;
}

.search-bar {
    margin-top: 10px;
    display: flex;
    justify-content: center;
    gap: 10px;
}

.search-input {
    padding: 8px;
    width: 300px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.search-button {
    background-color: #42b983;
    color: white;
    padding: 8px 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.district-list {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 30px;
    margin-top: 30px;
    justify-items: center;
}

.district-item {
    cursor: pointer;
    text-align: center;
    width: 480px;
    border-radius: 10px;
    overflow: hidden;
}

.district-image {
    width: 100%;
    height: 280px;
    border-radius: 8px;
    object-fit: cover;
    transition: transform 0.2s ease-in-out;
}

.district-image:hover {
    transform: scale(1.03);
}

.pagination {
    margin-top: 30px;
}

button {
    margin: 5px;
    padding: 10px 16px;
    border: none;
    background-color: #42b983;
    color: white;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

button:disabled {
    background-color: #ccc;
    cursor: not-allowed;
}

/* 返回按钮样式，定位到右上角 */
.back-button-container {
    position: absolute;
    top: 20px;
    right: 20px;
}

.back-button-container button {
    padding: 10px 20px;
    background-color: #42b983;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
</style>
