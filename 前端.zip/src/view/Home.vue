<template>
  <div class="home-container">
    <!-- 顶部导航栏 -->
    <nav class="navbar">
      <router-link to="/search" class="nav-item">旅游推荐</router-link>
      <router-link to="/diary" class="nav-item">旅游日记</router-link> <!-- ✅ 新增 -->
      <router-link to="/profile" class="nav-item">修改个人信息</router-link>
    </nav>

    <!-- 欢迎信息 -->
    <h1>欢迎回来，{{ username }}！</h1>
    <p>这是您的个人主页，您可以浏览旅游推荐或者修改个人信息。</p>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const username = ref('');

onMounted(() => {
  username.value = localStorage.getItem('username') || '游客';
  if (!localStorage.getItem('token')) {
    router.push('/login');  // 如果未登录，跳转到登录页面
  }
});
</script>

<style scoped>
.home-container {
  text-align: center;
  margin-top: 50px;
}

.navbar {
  display: flex;
  justify-content: center;
  background-color: #42b983;
  padding: 10px;
}

.nav-item {
  color: white;
  text-decoration: none;
  margin: 0 15px;
  font-size: 18px;
}

.nav-item:hover {
  text-decoration: underline;
}
</style>
