<template>
    <div class="diary-page">
        <h2>📝 我的旅游日记</h2>

        <div class="diary-form">
            <!-- 景点选择 -->
            <Multiselect v-model="selectedDistrict" :options="allDistricts" :searchable="true" :object="true"
                valueProp="id" label="name" :close-on-select="true" :clear-on-select="false" placeholder="请选择景点" />

            <textarea v-model="diaryContent" placeholder="记录你的旅行经历..." />

            <label>
                <input type="checkbox" v-model="isPublic" />
                是否公开（勾选为所有人可见）
            </label>

            <button @click="submitDiary">提交日记</button>
        </div>

        <div v-if="diaries.length" class="diary-list">
            <div v-for="diary in diaries" :key="diary.id" class="diary-item">
                <h4>
                    {{ getDistrictName(diary.districtId) }} · {{ formatTime(diary.createdTime) }}
                    <span v-if="!diary.isPublic" class="private-tag">（仅自己可见）</span>
                </h4>
                <p>{{ diary.content }}</p>
                <button v-if="diary.userId === userId" class="delete-button" @click="deleteDiary(diary.id)">
                    删除
                </button>
            </div>
        </div>

        <div v-else class="no-diary">你还没有写任何日记。</div>
    </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import api from '../api/api'
import Multiselect from '@vueform/multiselect'
import '@vueform/multiselect/themes/default.css'

interface DistrictOption {
    id: number
    name: string
}

const userId = Number(localStorage.getItem('userId'))
const allDistricts = ref<DistrictOption[]>([])
const selectedDistrict = ref<DistrictOption | null>(null)
const diaryContent = ref('')
const isPublic = ref(false)
const diaries = ref<any[]>([])

const fetchDistricts = async () => {
    const res = await api.get('/districts/all')
    allDistricts.value = res.data
}

const fetchDiaries = async () => {
    const res = await api.get(`/diaries/user/${userId}`)
    diaries.value = res.data
}

const submitDiary = async () => {
    if (!selectedDistrict.value || !diaryContent.value.trim()) {
        alert('请选择景点并填写内容')
        return
    }

    await api.post('/diaries', {
        userId,
        districtId: selectedDistrict.value.id,
        content: diaryContent.value,
        isPublic: isPublic.value,
    })

    // 清空表单
    diaryContent.value = ''
    isPublic.value = false
    selectedDistrict.value = null

    fetchDiaries()
}

const deleteDiary = async (id: number) => {
    try {
        await api.delete(`/diaries/${id}`, {
            headers: { userId: userId.toString() }
        })
        fetchDiaries()
    } catch (e) {
        alert('删除失败：' + (e?.response?.data || '未知错误'))
    }
}

const formatTime = (iso: string) => new Date(iso).toLocaleString()
const getDistrictName = (id: number) =>
    allDistricts.value.find(d => d.id === id)?.name || `景点#${id}`

onMounted(() => {
    fetchDistricts()
    fetchDiaries()
})
</script>

<style scoped>
.diary-page {
    max-width: 680px;
    margin: 0 auto;
    padding: 24px;
}

.diary-form {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 24px;
}

textarea {
    min-height: 120px;
    padding: 8px;
    resize: vertical;
    border: 1px solid #ddd;
    border-radius: 6px;
}

button {
    align-self: flex-start;
    padding: 6px 16px;
    background: #409eff;
    color: #fff;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

button:hover {
    opacity: 0.9;
}

.delete-button {
    background: #f56c6c;
    margin-top: 8px;
}

.diary-item {
    margin-bottom: 16px;
    padding: 12px;
    background: #fafafa;
    border: 1px solid #eee;
    border-radius: 6px;
}

.private-tag {
    color: #888;
    font-size: 12px;
}

.no-diary {
    color: #999;
    margin-top: 10px;
}
</style>
  
