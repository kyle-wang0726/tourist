<template>
    <div class="diary-page">
        <h2>📝 我的旅游日记</h2>

        <!-- 写日记表单 -->
        <div class="diary-form">
            <select v-model="selectedDistrictId">
                <option disabled value="">请选择景点</option>
                <option v-for="d in allDistricts" :key="d.id" :value="d.id">
                    {{ d.name }}
                </option>
            </select>
            <textarea v-model="diaryContent" placeholder="记录你的旅行经历..." />
            <button @click="submitDiary">提交日记</button>
        </div>

        <!-- 显示日记 -->
        <div class="diary-list">
            <div v-for="diary in diaries" :key="diary.id" class="diary-item">
                <h4>{{ getDistrictName(diary.districtId) }} · {{ formatTime(diary.createdTime) }}</h4>
                <p>{{ diary.content }}</p>
            </div>
        </div>

        <div v-if="diaries.length === 0" class="no-diary">你还没有写任何日记。</div>
    </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import api from '../api/api';

const userId = Number(localStorage.getItem('userId'));
const allDistricts = ref<any[]>([]);
const diaries = ref<any[]>([]);

const selectedDistrictId = ref<number | ''>('');
const diaryContent = ref('');

const fetchDistricts = async () => {
    const res = await api.get('/districts/all');  // ✅ 改为调用新的非分页接口
    allDistricts.value = res.data;
};


const fetchDiaries = async () => {
    const res = await api.get(`/diaries/user/${userId}`);
    diaries.value = res.data;
};

const submitDiary = async () => {
    if (!selectedDistrictId.value || !diaryContent.value.trim()) {
        alert('请填写完整内容');
        return;
    }

    await api.post('/diaries', {
        userId,
        districtId: selectedDistrictId.value,
        content: diaryContent.value,
    });

    diaryContent.value = '';
    selectedDistrictId.value = '';
    fetchDiaries();
};

const getDistrictName = (id: number) => {
    const match = allDistricts.value.find(d => d.id === id);
    return match ? match.name : `景点 #${id}`;
};

const formatTime = (iso: string) => {
    return new Date(iso).toLocaleString();
};

onMounted(() => {
    fetchDistricts();
    fetchDiaries();
});
</script>

<style scoped>
.diary-page {
    max-width: 900px;
    margin: 0 auto;
    padding: 30px;
}

.diary-form {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 30px;
}

.diary-form select,
.diary-form textarea {
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

.diary-form button {
    align-self: flex-start;
    background-color: #42b983;
    color: white;
    padding: 8px 16px;
    border-radius: 5px;
    border: none;
    cursor: pointer;
}

.diary-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.diary-item {
    background: #fdfdfd;
    border-left: 5px solid #42b983;
    padding: 12px 16px;
    border-radius: 6px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.no-diary {
    color: #888;
    font-style: italic;
}
</style>
