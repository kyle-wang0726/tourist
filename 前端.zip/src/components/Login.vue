<template>
  <div class="login-container">
    <h2>用户登录</h2>
    <input v-model="username" placeholder="用户名" class="input-box" />
    <input v-model="password" type="password" placeholder="密码" class="input-box" />
    <button @click="login" class="login-button">登录</button>
    <p v-if="message" class="message">{{ message }}</p>
    <p>没有账号？<router-link to="/register">注册</router-link></p>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import api from '../api/api';

const router = useRouter();
const username = ref('');
const password = ref('');
const message = ref('');

const login = async () => {
  try {
    const response = await api.post('/auth/login', {
      username: username.value,
      password: password.value,
    });

    // 打印返回的 API 响应数据
    console.log('登录返回的数据:', response.data);

    if (response.data.token) {
      // 保存到 localStorage
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('userId', response.data.userId);

      message.value = '登录成功！正在跳转...';

      // 登录成功后跳转到主页
      setTimeout(() => {
        router.push('/home');
      }, 1000);
    } else {
      message.value = '登录失败，请检查用户名和密码';
    }
  } catch (error) {
    console.error('登录错误', error);
    message.value = error.response?.data || '登录失败，请检查用户名和密码';
  }
};
</script>

<style scoped>
.login-container {
  max-width: 300px;
  margin: 50px auto;
  padding: 20px;
  text-align: center;
  border: 1px solid #ddd;
  border-radius: 10px;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
}

.input-box {
  display: block;
  width: 90%;
  padding: 10px;
  margin: 10px auto;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.login-button {
  width: 95%;
  padding: 10px;
  background-color: #42b983;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.message {
  margin-top: 10px;
  color: red;
}
</style>
