<template>
    <div class="register-container">
        <h2>用户注册</h2>
        <input v-model="username" placeholder="用户名" class="input-box" />
        <input v-model="email" type="email" placeholder="邮箱" class="input-box" />
        <input v-model="password" type="password" placeholder="密码" class="input-box" />
        <button @click="register" class="register-button">注册</button>
        <p v-if="message" class="message">{{ message }}</p>
        <p>已有账号？<router-link to="/">登录</router-link></p>
    </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import api from '../api/api';

const username = ref('');
const email = ref('');
const password = ref('');
const message = ref('');
const router = useRouter();

const register = async () => {
    try {
        const response = await api.post('/auth/register', {
            username: username.value,
            email: email.value,
            password: password.value,
        });
        message.value = '注册成功！请登录';
        setTimeout(() => { router.push('/'); }, 2000);
    } catch (error) {
        message.value = error.response?.data || '注册失败，请重试';
    }
};
</script>

<style scoped>
.register-container {
    max-width: 300px;
    margin: 50px auto;
    padding: 20px;
    text-align: center;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
}

.input-box {
    display: block;
    width: 90%;
    padding: 10px;
    margin: 10px auto;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.register-button {
    width: 95%;
    padding: 10px;
    background-color: #42b983;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.message {
    margin-top: 10px;
    color: red;
}
</style>
