import axios from 'axios';

const api = axios.create({
  baseURL: "http://localhost:8080", // Spring Boot ????
  timeout: 5000,
  headers: { "Content-Type": "application/json" },
});

export const getDistricts = (page = 0, size = 10) => {
  return api.get("/districts", {
    params: { page, size },
  });
};


export const getDistrictById = (id: number) => {
  return api.get(`/districts/${id}`);
};

// ? ???? + ????
export const searchDistricts = (query: string, page: number = 0, size: number = 10) => {
  return api.get(`/districts/search`, {
    params: { query, page, size }
  });
};

// api.ts
export const fuzzySearchDistricts = (query: string, page = 0, size = 10) => {
  return api.get("/districts/fuzzy-search", {
    params: { query, page, size },
  });
};

export default api;
