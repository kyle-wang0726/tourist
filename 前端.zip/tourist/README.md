# 组件使用
组件哪里看着不顺眼改了就行，因为电脑的分辨率不同，还是以正常笔记本的屏幕为准

## 下拉框 (SelectMenu)

需要传入三个参数: 
1. itemTag   (String 下拉框上面那个种类 )
2. itemList  (Array 传入所有可选的数据)
3. defaultItem (String 默认选中的)

## 身份选择 (SelectRole)

直接用就好

## 比赛场次 (ContestItem)
首先需要导入一个枚举类:ContestKind
import ContestKind from "../hook/ContestKind"

需要传入三个参数:
1. date (String 比赛时间 建议以 24/12/2 的格式)
2. kind (ContestKind 出题方)
3. name (String 比赛名称)
