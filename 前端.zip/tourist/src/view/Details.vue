<template>
    <div class="detail-container" v-if="district">
        <h2>{{ district.name }}</h2>
        <img :src="district.imageUrl" alt="景点图片" class="detail-image" />
        <p><strong>位置：</strong>{{ district.location }}</p>
        <p><strong>评分：</strong>{{ district.avgScore }}</p>
        <p><strong>热度：</strong>{{ district.heat }}</p>
        <p><strong>简介：</strong>{{ district.introduction }}</p>
        <p><strong>开放时间：</strong>{{ district.openTime }}</p>
    </div>
    <div v-else>
        <p>正在加载数据...</p>
    </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
import api from "../api/api";

const route = useRoute();
const district = ref(null);

const fetchDistrictDetail = async () => {
    try {
        const response = await api.get(`/districts/${route.params.id}`);
        district.value = response.data;
    } catch (error) {
        console.error("获取景点详情失败:", error);
    }
};

onMounted(fetchDistrictDetail);
</script>

<style scoped>
.detail-container {
    text-align: center;
    padding: 20px;
}

.detail-image {
    width: 300px;
    height: 200px;
    object-fit: cover;
    border-radius: 8px;
}
</style>
