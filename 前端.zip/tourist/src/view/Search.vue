<template>
    <div class="search-container">
        <h2>旅游景点推荐</h2>

        <!-- 景点列表 -->
        <div class="district-list">
            <div v-for="district in displayedDistricts" :key="district.id" class="district-item">
                <img :src="district.imageUrl" alt="景点图片" class="district-image" @click="goToDetail(district.id)"
                    @error="handleImageError" />
                <h3>{{ district.name }}</h3>
            </div>
        </div>

        <!-- 分页控制 -->
        <div class="pagination">
            <button @click="prevPage" :disabled="currentPage === 1">上一页</button>
            <span>第 {{ currentPage }} 页 / 共 {{ totalPages }} 页</span>
            <button @click="nextPage" :disabled="currentPage >= totalPages">下一页</button>
        </div>
    </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import { useRouter } from "vue-router";
import api from "../api/api";

const router = useRouter();
const districts = ref([]); // 存储景点数据
const currentPage = ref(1);
const pageSize = 10; // 每页显示 10 条数据

// **计算总页数**
const totalPages = computed(() => Math.ceil(districts.value.length / pageSize));

// **计算当前页显示的数据**
const displayedDistricts = computed(() => {
    const start = (currentPage.value - 1) * pageSize;
    return districts.value.slice(start, start + pageSize);
});

// **获取景点数据**
const fetchDistricts = async () => {
    try {
        const response = await api.get("/districts");
        console.log("获取到的景点数据：", response.data); // ✅ 日志输出
        districts.value = response.data.map((item) => ({
            id: item.id,
            name: item.name,
            imageUrl: item.imageUrl || "https://via.placeholder.com/150" // 默认图片
        }));
    } catch (error) {
        console.error("获取景点数据失败:", error);
    }
};

// **跳转到详情页面**
const goToDetail = (id) => {
    console.log("跳转到景点详情，ID:", id); // ✅ 日志输出
    router.push(`/detail/${id}`);
};

// **分页控制**
const prevPage = () => {
    if (currentPage.value > 1) currentPage.value--;
};

const nextPage = () => {
    if (currentPage.value < totalPages.value) currentPage.value++;
};

// **处理图片加载错误**
const handleImageError = (event) => {
    event.target.src = "https://via.placeholder.com/150"; // 备用图片
};

// **组件挂载后获取数据**
onMounted(fetchDistricts);
</script>

<style scoped>
.search-container {
    text-align: center;
    padding: 20px;
}

.district-list {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
    margin-top: 20px;
}

.district-item {
    cursor: pointer;
    text-align: center;
    width: 200px;
    border-radius: 10px;
    overflow: hidden;
}

.district-image {
    width: 100%;
    height: 150px;
    border-radius: 8px;
    object-fit: cover;
    transition: transform 0.2s ease-in-out;
}

.district-image:hover {
    transform: scale(1.05);
}

.pagination {
    margin-top: 20px;
}

button {
    margin: 5px;
    padding: 8px 12px;
    border: none;
    background-color: #42b983;
    color: white;
    border-radius: 5px;
    cursor: pointer;
}

button:disabled {
    background-color: #ccc;
    cursor: not-allowed;
}
</style>
