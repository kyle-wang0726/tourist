import axios from 'axios';

const api = axios.create({
  baseURL: "http://localhost:8080", // Spring Boot ??
  timeout: 5000,
  headers: { "Content-Type": "application/json" },
});

// ??????????
export const getDistricts = (page: number) => {
  return api.get(`/districts?page=${page}`);
};

// ????????
export const getDistrictById = (id: number) => {
  return api.get(`/districts/${id}`);
};

export default api;
