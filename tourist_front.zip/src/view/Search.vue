<template>
    <div class="search-container">
        <h1>旅游推荐</h1>
        <p>这里是未来的旅游搜索和推荐系统，敬请期待！</p>
        <button class="back-button" @click="goHome">返回主界面</button>
    </div>
</template>

<script setup>
import { useRouter } from 'vue-router';

const router = useRouter();

const goHome = () => {
    router.push('/home');
};
</script>

<style scoped>
.search-container {
    text-align: center;
    margin-top: 50px;
}

.back-button {
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #42b983;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.back-button:hover {
    background-color: #368a6c;
}
</style>
