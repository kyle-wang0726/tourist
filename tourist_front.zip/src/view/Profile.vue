<template>
    <div class="profile-container">
        <h2>修改个人信息</h2>
        <input v-model="username" placeholder="新用户名" class="input-box" />
        <input v-model="email" type="email" placeholder="新邮箱" class="input-box" />
        <input v-model="password" type="password" placeholder="新密码（可选）" class="input-box" />
        <button @click="updateProfile" class="update-button">保存修改</button>
        <p v-if="message" class="message">{{ message }}</p>
        <button class="back-button" @click="goHome">返回主界面</button>
    </div>
</template>

<script setup>
import { ref } from 'vue';
import api from '../api/api';
import { useRouter } from 'vue-router';

const router = useRouter();
const username = ref(localStorage.getItem('username') || '');
const email = ref('');
const password = ref('');
const message = ref('');

const updateProfile = async () => {
    try {
        const response = await api.put('/auth/update-profile', {
            username: username.value,
            email: email.value,
            password: password.value,
        });

        message.value = '个人信息更新成功！';
        localStorage.setItem('username', username.value);
        setTimeout(() => router.push('/home'), 2000);
    } catch (error) {
        message.value = '修改失败，请重试';
    }
};

const goHome = () => {
    router.push('/home');
};
</script>

<style scoped>
.profile-container {
    max-width: 300px;
    margin: 50px auto;
    padding: 20px;
    text-align: center;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
}

.input-box {
    display: block;
    width: 90%;
    padding: 10px;
    margin: 10px auto;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.update-button,
.back-button {
    width: 95%;
    padding: 10px;
    margin-top: 10px;
    background-color: #42b983;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.back-button {
    background-color: #3498db;
}

.back-button:hover {
    background-color: #2980b9;
}

.message {
    margin-top: 10px;
    color: red;
}
</style>
