<template>
  <div class="login-container">
    <h2>用户登录</h2>
    <input v-model="username" placeholder="用户名" class="input-box" />
    <input v-model="password" type="password" placeholder="密码" class="input-box" />
    <button @click="login" class="login-button">登录</button>
    <p v-if="message" class="message">{{ message }}</p>
    <p>没有账号？<router-link to="/register">注册</router-link></p>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import api from '../api/api';

const router = useRouter();
const username = ref('');
const password = ref('');
const message = ref('');

const login = async () => {
  try {
    const response = await api.post('/auth/login', {
      username: username.value,
      password: password.value,
    });

    // **存储 token 和 username，方便后续页面获取**
    localStorage.setItem('token', response.data.token);
    localStorage.setItem('username', username.value);

    message.value = '登录成功！正在跳转...';

    // **使用 Vue Router 跳转，而不是 window.location.href**
    setTimeout(() => {
      router.push('/home');
    }, 1000);
  } catch (error) {
    message.value = error.response?.data || '登录失败，请检查用户名和密码';
  }
};
</script>

<style scoped>
.login-container {
  max-width: 300px;
  margin: 50px auto;
  padding: 20px;
  text-align: center;
  border: 1px solid #ddd;
  border-radius: 10px;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
}

.input-box {
  display: block;
  width: 90%;
  padding: 10px;
  margin: 10px auto;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.login-button {
  width: 95%;
  padding: 10px;
  background-color: #42b983;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.message {
  margin-top: 10px;
  color: red;
}
</style>
