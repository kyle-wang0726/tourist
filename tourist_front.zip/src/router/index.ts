import { createRouter, createWebHistory } from "vue-router";
import Home from "@/view/Home.vue";
import Login from "@/components/Login.vue";
import Register from "@/components/Register.vue";
import Search from "@/view/Search.vue";  // 添加旅游搜索页面
import Profile from "@/view/Profile.vue";  // 添加个人信息页面

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      redirect: "/login",
    },
    {
      path: "/login",
      component: Login,
    },
    {
      path: "/register",
      component: Register,
    },
    {
      path: "/home",
      component: Home,
    },
    {
      path: "/search",
      component: Search,  // 旅游推荐
    },
    {
      path: "/profile",
      component: Profile,  // 个人信息管理
    },
  ],
});

export default router;
